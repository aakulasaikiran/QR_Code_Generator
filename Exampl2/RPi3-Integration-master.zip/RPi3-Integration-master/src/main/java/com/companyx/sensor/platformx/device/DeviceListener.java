package com.companyx.sensor.platformx.device;

public interface DeviceListener {
	void onData(DeviceData data);
}
