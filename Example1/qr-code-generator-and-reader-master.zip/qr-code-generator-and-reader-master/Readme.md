# Generate and Read QR Code in Java

Relevant Tutorials -

+ https://www.callicoder.com/generate-qr-code-in-java-using-zxing/
+ https://www.callicoder.com/qr-code-reader-scanner-in-java-using-zxing/

## Steps to Run

1. Clone the repository

```
git clone git@github.com:callicoder/qr-code-generator-and-reader.git
```

2. Run the program using maven

```
cd qr-code-generator-and-reader
mvn package
java -jar target/qr-code-generator-and-reader-1.0-SNAPSHOT.jar 
```

